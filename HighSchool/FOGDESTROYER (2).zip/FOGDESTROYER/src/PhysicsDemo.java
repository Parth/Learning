import org.jbox2d.dynamics.*;
import org.lwjgl.LWJGLException;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.lwjgl.opengl.GL11;
import org.jbox2d.dynamics.World;
import org.jbox2d.common.*;
import java.util.*;
import org.jbox2d.dynamics.Body;
import org.jbox2d.collision.shapes.PolygonShape;
import org.jbox2d.dynamics.BodyDef;
import java.util.Set;

public class PhysicsDemo {

	private static World world = new World(new Vec2(0, -9.8f), false);
	private static Set<Clark> clarks = new HashSet<Clark>();

	private static void setupDisplays() {
		try {
			Display.setFullscreen(true);
			Display.create();
		} catch (LWJGLException e) {
		}
	}

	private static void setupObjects() {
		Clark myClarkyPoo = new Clark(world, 320/30, 240/30, 0.75f, 0.75f);
		clarks.add(myClarkyPoo);
	}

	private static void setupMatrices() {
		GL11.glMatrixMode(GL11.GL_PROJECTION);
		GL11.glOrtho(0, 640, 0, 480 , 1 , -1);
		GL11.glMatrixMode(GL11.GL_MODELVIEW);
	}
	
	private static void enterGameLoop() {
		while (!Display.isCloseRequested()) {
			render();
			logic();
			update();

		}
	}

	private static void render() {
		GL11.glClear(GL11.GL_COLOR_BUFFER_BIT);
		for (Clark clark : clarks) {
			GL11.glPushMatrix();
			//Maybe
			Vec2 bodyPosition = clark.getBody().getPosition().mul(30);
			GL11.glTranslatef(bodyPosition.x, bodyPosition.y, 0);
			GL11.glRotatef((float) Math.toDegrees(clark.getBody().getAngle()), 0f, 0f, 1f);
			GL11.glRectf(-clark.width * 30, -clark.height * 30, clark.width * 30, clark.height * 30);
			GL11.glPopMatrix();
		}
	}

	private static void logic() {
		world.step(1/60f, 8, 3);

	}

	private static void update() {
		Display.update();
		Display.sync(60);
	}

	public static void main(String[] args) {
		setupDisplays();
		setupObjects();
		setupMatrices();
		enterGameLoop();
	}
}
