import org.jbox2d.dynamics.*;
import org.lwjgl.LWJGLException;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.lwjgl.opengl.GL11;
import org.jbox2d.dynamics.World;
import org.jbox2d.common.*;
import java.util.*;
import org.jbox2d.dynamics.Body;
import org.jbox2d.collision.shapes.PolygonShape;
import org.jbox2d.dynamics.BodyDef;
import java.util.Set;

public class Clark {
	public float width, height;
	public int x, y;
	private World wo;
	private Body body;

	public Clark(World wo, int x, int y, float w, float h) {
		this.x = x;
		this.y = y;
		this.width = w;
		this.height = h;

		this.wo = wo;
		
		BodyDef bodyDef = new BodyDef();
		//bodyDef.position.set(320/30/1, 240/30/1);
		bodyDef.position.set(x, y);
		bodyDef.type = BodyType.DYNAMIC;
		PolygonShape boxShape = new PolygonShape();
		//0.75
		boxShape.setAsBox(width, height);
		body = this.wo.createBody(bodyDef);
		FixtureDef boxFixture = new FixtureDef();
		boxFixture.density = 1;
		boxFixture.shape = boxShape;
		body.createFixture(boxFixture);
	}

	public Body getBody() {
		return body;
	}

}

