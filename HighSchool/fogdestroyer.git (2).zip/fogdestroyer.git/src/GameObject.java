import org.jbox2d.dynamics.World;
import org.jbox2d.dynamics.Body;
import org.jbox2d.common.Vec2;

public interface GameObject {
	public void render();
	public void attachPhysics(World w);
	public void attachPhysics(World w, Vec2 v);
	public Body getBody();
}
