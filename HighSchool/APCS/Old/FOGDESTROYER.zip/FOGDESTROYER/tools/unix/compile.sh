FILES=(
	../../src/PhysicsDemo.java
)
javac -cp :../../libs/slf4j.jar:../../libs/log4j.jar:../../libs/lwjgl.jar:../../libs/lwjgl_util.jar:../../libs/jbox2d.jar:../../out/production/FOGDESTROYER -d ../../out/production/FOGDESTROYER/ ${FILES[*]}
