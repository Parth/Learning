import org.jbox2d.dynamics.*;
import org.lwjgl.LWJGLException;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.lwjgl.opengl.GL11;
import org.jbox2d.dynamics.World;
import org.jbox2d.common.*;
import java.util.*;
import org.jbox2d.dynamics.Body;
import org.jbox2d.collision.shapes.PolygonShape;
import org.jbox2d.dynamics.BodyDef;
import java.util.Set;

public class PhysicsDemo {

	private static World world = new World(new Vec2(0, -9.8f), false);
	private static Set<Body> bodies = new HashSet<Body>();

	private static void render() {
		GL11.glClear(GL11.GL_COLOR_BUFFER_BIT);
		for (Body body : bodies) {
			if (body.getType() == BodyType.DYNAMIC) {
				GL11.glPushMatrix();
				Vec2 bodyPosition = body.getPosition().mul(30);
				GL11.glTranslatef(bodyPosition.x, bodyPosition.y, 0);
				GL11.glRotatef((float) Math.toDegrees(body.getAngle()), 0f, 0f, 1f);
				GL11.glRectf(-0.75f * 30, -0.75f * 30, 0.75f * 30, 0.75f * 30);
				GL11.glPopMatrix();
			}
		}
	}

	private static void setupObjects() {
		BodyDef bodyDef = new BodyDef();
		bodyDef.position.set(320/30/2, 240/30/2);
		bodyDef.type = BodyType.DYNAMIC;
		PolygonShape boxShape = new PolygonShape();
		boxShape.setAsBox(0.75f, 0.75f);
		Body box = world.createBody(bodyDef);
		FixtureDef boxFixture = new FixtureDef();
		boxFixture.density = 1;
		boxFixture.shape = boxShape;
		box.createFixture(boxFixture);
		bodies.add(box);
	}

	private static void logic() {
		world.step(1/60f, 8, 3);

	}

	private static void input() {

	}

	private static void cleanUp(boolean asCrash) {
	}

	private static void setupMatrices() {
		GL11.glMatrixMode(GL11.GL_PROJECTION);
		GL11.glOrtho(0, 320, 0, 240,1, -1);
		GL11.glMatrixMode(GL11.GL_MODELVIEW);
	}

	private static void setupStates() {
	}

	private static void update() {
		Display.update();
		Display.sync(60);
	}

	private static void enterGameLoop() {
		while (!Display.isCloseRequested()) {
			render();
			logic();
			input();
			update();

		}
	}

	private static void setupDisplays() {
		try {
			Display.setDisplayMode(new DisplayMode(800, 600));
			Display.create();
		} catch (LWJGLException e) {
			cleanUp(false);
		}
	}

	public static void main(String[] args) {
		setupDisplays();
		setupStates();
		setupObjects();
		setupMatrices();
		enterGameLoop();
		cleanUp(false);
	}

}
