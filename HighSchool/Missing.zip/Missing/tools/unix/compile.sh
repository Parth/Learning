FILES=(
	../../src/PhysicsDemo.java
	../../src/Block.java
	../../src/Cell.java
	../../src/GameObject.java
	../../src/Grid.java
	../../src/Wall.java
)
javac -cp :../../libs/slf4j.jar:../../libs/log4j.jar:../../libs/lwjgl.jar:../../libs/lwjgl_util.jar:../../libs/jbox2d.jar:../../out/production/FOGDESTROYER -d ../../out/production/FOGDESTROYER/ ${FILES[*]}
