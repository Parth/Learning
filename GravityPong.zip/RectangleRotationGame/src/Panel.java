import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyListener;

import javax.swing.JPanel;

public class Panel extends JPanel implements Runnable {

	private Thread th;
	private double clock = 0;
	private int fps;
	public static int theta = 0;

	public static Paddle paddle;
	public static Ball ball;
	
	
	public Panel() {
		paddle = new Paddle(25, 100, Color.blue);
		ball = new Ball(25, Color.white);
		
		th = new Thread(this);
		th.start();
	}

	public void paintComponent(Graphics g) {
		g.clearRect(0, 0, Frame.W, Frame.H);
		paddle.draw(g);
		//g.drawOval(Frame.W/2 - 200/2, Frame.H/2 - 200/2, 200, 200);

		//drawGuideLines(5, 5, Color.white, g);
	}

	@Override
	public void run() {


		while (true) {
			gameLoop();
			tick();
			try {
				Thread.sleep(50);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	

	public void gameLoop() {
		paddle.move(theta);
		repaint();
	}

	public void tick() {
		clock+=1.0;
	}

	public void drawGuideLines(int numberOfXLines, int numberOfYLines,
			Color color, Graphics g) {

		int nX = numberOfXLines + 1;
		int nY = numberOfYLines + 1;

		g.setColor(color);

		for (int x = 0; x < nX; x++) {
			g.drawLine((Frame.W / nX) + (x * (Frame.W / nX)), 0, (Frame.W / nX)
					+ (x * (Frame.W / nX)), Frame.H);
		}

		for (int y = 0; y < nY; y++) {
			g.drawLine(0, (Frame.H / nY) + (y * (Frame.H / nY)), Frame.W,
					(Frame.H / nY) + (y * (Frame.H / nY)));
		}
	}
}
