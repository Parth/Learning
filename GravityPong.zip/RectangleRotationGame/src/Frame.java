import java.awt.Color;
import java.awt.Point;

import javax.swing.JFrame;

public class Frame {
	
	public static InputHandler inputHandler;

	public static final int W = 800, H = 600;
	public static final Point origin = new Point(W / 2, H / 2);

	public static void main(String args[]) {
		JFrame frame = new JFrame();
		frame.setSize(W, H);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setBackground(Color.black);
		frame.setTitle("Rectangle Rotation");
		frame.setVisible(true);
		frame.setResizable(false);
		frame.add(new Panel());
		inputHandler = new InputHandler();
		frame.addMouseMotionListener(inputHandler);
	}
}
