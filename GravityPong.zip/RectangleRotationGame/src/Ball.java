import java.awt.Color;
import java.awt.Graphics;
import java.awt.Polygon;


public class Ball {
	
	Polygon ball;
	
	public Ball(int rad, Color color) {
		
	}
	
	public void draw(Graphics g) {
	
	}

}
