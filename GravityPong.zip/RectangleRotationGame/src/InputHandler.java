import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;


public class InputHandler implements MouseMotionListener {

	@Override
	public void mouseDragged(MouseEvent e) {

	}

	@Override
	public void mouseMoved(MouseEvent e) {
		Point eFromOrigin = new Point(e.getX() - Frame.origin.x, e.getY() - Frame.origin.y);
		double theta = Math.toDegrees(Math.atan2(eFromOrigin.x , eFromOrigin.y));
		Panel.theta = (int) (-theta + 90);
	}


}
